jQuery(document).ready(function ($) {
    $("#sortable").sortable();
    $("#sortable").disableSelection();
});
