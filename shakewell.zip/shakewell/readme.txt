I added the working Demo Vedio inside Shakewell folder.

Also, please add below code in any page to display the sortcode in frontend.

<?php echo do_shortcode("[mylistdemo]"); ?>