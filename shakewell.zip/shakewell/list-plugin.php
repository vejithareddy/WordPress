<?php
/*
Plugin Name: My List Demo Plugin
Description: Plugin Challenge.
Author: vejitha
*/


function my_list_plugin_menu() {
    add_menu_page('List Settings', 'List Demo Settings', 'manage_options', 'my-list-settings', 'my_list_settings_page');
}

// Hook to add the settings page
add_action('admin_menu', 'my_list_plugin_menu');

function my_list_plugin_settings() {
    register_setting('my_list_plugin_settings', 'my_list_items','sanitize_callback');
    add_settings_section('my_list_section', 'List Items', 'my_list_section_callback', 'my-list-settings');
    add_settings_field('my_list_items', 'Items', 'my_list_items_callback', 'my-list-settings', 'my_list_section');
}

add_action('admin_init', 'my_list_plugin_settings');

function my_list_section_callback() {
    echo 'Add, remove, and rearrange items for the list.';
}

function my_list_items_callback() {
    $items = get_option('my_list_items');
    $items = is_array($items) ? $items : array();
   echo '<ul id="sortable" class="connectedSortable">';
    foreach ($items as $item) {
        echo '<li>' . esc_html($item) . '</li>';
    }
    echo '</ul>';
    
    echo '<input type="text" name="my_list_items[]" placeholder="Item 1" />';
    echo '<input type="text" name="my_list_items[]" placeholder="Item 2" />';
    echo '<input type="text" name="my_list_items[]" placeholder="Item 3" />';

}



// Sanitization callback function
function sanitize_callback($input) {
    // Sanitize and validate input before saving to the database
    return array_map('sanitize_text_field', $input);
}

function my_list_settings_page() {
    ?>
    <div class="wrap">
        <h2>My List Demo Settings</h2>
        <form method="post" action="options.php">
            <?php
            settings_fields('my_list_plugin_settings');
            do_settings_sections('my-list-settings');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

function my_list_enqueue_scripts() {
    wp_enqueue_script('jquery');
    wp_enqueue_script('jquery-ui-sortable');
    wp_enqueue_script('plugin-scripts', plugin_dir_url(__FILE__) . 'js/plugin-scripts.js', array('jquery', 'jquery-ui-sortable'), true);
}

add_action('admin_enqueue_scripts', 'my_list_enqueue_scripts');

function my_list_shortcode() {
    $items = get_option('my_list_items');
    $items = is_array($items) ? $items : array();
    ob_start();
    echo '<ul>';
    foreach ($items as $item) {
        echo '<li>' . esc_html($item) . '</li>';
    }
    echo '</ul>';
    return ob_get_clean();
}

add_shortcode('mylistdemo', 'my_list_shortcode');


